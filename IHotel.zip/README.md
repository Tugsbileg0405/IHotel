# ihotel-revised
Revised version of ihotel.mn
