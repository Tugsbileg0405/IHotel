<?php $__env->startSection('title', '500'); ?>

<?php $__env->startSection('content'); ?>
<div class="ui container">
    <h2>500</h2>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>