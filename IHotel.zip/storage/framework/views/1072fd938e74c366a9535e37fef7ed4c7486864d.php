<div class="ui fluid vertical pointing menu">
	<a class="active item">
		Үндсэн мэдээлэл
	</a>
	<a class="item">
		Буудлын мэдээлэл
	</a>
	<a class="item">
		Өрөөний товч мэдээлэл
	</a>
	<a class="item">
		Өрөөний дэлгэрэнгүй мэдээлэл
	</a>
	<a class="item">
		Төлбөрийн нөхцөл
	</a>
	<a class="item">
		Гэрээ хийх
	</a>
</div>