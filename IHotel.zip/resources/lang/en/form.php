<?php

return [

    'Please enter your name' => 'Please enter your name',
    'Please enter your surname' => 'Please enter your surname',
    'Please enter your country' => 'Please enter your country',
    'Please enter at most 191 characters' => 'Please enter at most 191 characters',
    'Please enter your email' => 'Please enter your email',
    'Please enter a message' => 'Please enter a message',
    'Please enter your password' => 'Please enter your password',
    'Please enter at least 6 characters' => 'Please enter at least 6 characters',
    'Please agree terms of service' => 'Please agree terms of service',
    'Please enter a value' => 'Please enter a value',
    'Password doesnt match' => 'Password doesnt match',
    'Please select a score' => 'Please select a score',
    'Card number is wrong' => 'Card number is wrong',
    'Please enter a valid expiry date' => 'Please enter a valid expiry date'
];