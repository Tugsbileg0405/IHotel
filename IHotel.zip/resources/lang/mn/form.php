<?php

return [

    'Please enter your name' => 'Нэр оруулна уу',
    'Please enter your surname' => 'Овог оруулна уу',
    'Please enter your country' => 'Улс оруулна уу',
    'Please enter at most 191 characters' => 'Та хамгийн ихдээ 191 тэмдэгт оруулах боломжтой',
    'Please enter your email' => 'И-мэйл хаяг оруулна уу',
    'Please enter a message' => 'Хүсэлт оруулна уу',
    'Please enter your password' => 'Нууц үг оруулна уу',
    'Please enter at least 6 characters' => 'Та хамгийн багадаа 6 тэмдэгт оруулах боломжтой',
    'Please agree terms of service' => 'Үйлчилгээний нөхцөл зөвшөөрөөгүй байна',
    'Please enter a value' => 'Утга оруулна уу',
    'Password doesnt match' => 'Нууц үг таарахгүй байна',
    'Please select a score' => 'Оноо сонгоно уу',
    'Card number is wrong' => 'Картын дугаар буруу байна.',
    'Please enter a valid expiry date' => 'Картын хугацаа дууссан байна.',
];
