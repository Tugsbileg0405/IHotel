<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'И-мэйл эсвэл нууц үг буруу байна.',
    'throttle' => 'Хэт олон нэвтрэх оролдлого хийсэн байна. Та :seconds секунд хүлээгээд дахин оролдоно уу.',
    'wait' => 'Түр хүлээнэ үү...',
];
